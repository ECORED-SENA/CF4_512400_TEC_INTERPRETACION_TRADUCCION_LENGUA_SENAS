function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5o8Os4mVcyI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

