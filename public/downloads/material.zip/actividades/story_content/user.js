function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5gHJ48LpMfJ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

